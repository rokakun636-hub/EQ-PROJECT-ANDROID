plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sanusi.eqproject"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sanusi.eqproject"
        minSdk = 23
        targetSdk = 35
        versionCode = 60
        versionName = "6.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("com.google.guava:guava:33.3.1-android")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
}
