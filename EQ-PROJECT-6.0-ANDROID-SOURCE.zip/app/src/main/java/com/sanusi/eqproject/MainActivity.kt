package com.sanusi.eqproject

import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors

class MainActivity : AppCompatActivity() {
    private var controller: MediaController? = null
    private lateinit var status: TextView
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        uris.forEach { uri -> contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        controller?.setMediaItems(uris.map { MediaItem.fromUri(it) })
        controller?.prepare()
        controller?.play()
        status.text = "Memutar ${uris.size} lagu • Audio dapat berjalan di latar belakang"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,48,32,32); setBackgroundColor(0xFF080D18.toInt()) }
        status = TextView(this).apply { text = "EQ PROJECT 6.0 • by SANUSI\nPilih musik untuk mulai"; textSize = 18f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0,0,0,28) }
        fun btn(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
        layout.addView(status)
        layout.addView(btn("＋ Tambah Musik") { picker.launch(arrayOf("audio/*")) })
        layout.addView(btn("▶ Putar") { controller?.play() })
        layout.addView(btn("❚❚ Jeda") { controller?.pause() })
        layout.addView(btn("■ Berhenti") { controller?.stop() })
        layout.addView(btn("⏮ Sebelumnya") { controller?.seekToPreviousMediaItem() })
        layout.addView(btn("⏭ Berikutnya") { controller?.seekToNextMediaItem() })
        setContentView(layout)
    }
    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ try { controller = future.get() } catch (e: Exception) { Toast.makeText(this, "Gagal menghubungkan pemutar", Toast.LENGTH_LONG).show() } }, MoreExecutors.directExecutor())
    }
    override fun onStop() {
        controller?.release()
        controller = null
        super.onStop()
    }
}
